<?php
$mysql_server = "localhost";
$mysql_user = "root";
$mysql_password = "";
$mysql_database = "game";
$timeoutseconds = 300000; 

$connection = mysql_connect("$mysql_server","$mysql_user","$mysql_password") or die ("Unable to connect to MySQL server. Sorry bout this we got a few technical errors.");

$db = mysql_select_db("$mysql_database") or die ("ERROR ! datebase has been changed and the changes have not been edited on the conection please wait and it shall be changed.");

?>